# Land of Jail – Auto Hunter (prototype source)

This is an Android Studio project scaffold for a Level 30 Frenzied Fugitive helper.

## Current status
- Android app shell and Accessibility Service configuration are included.
- ML Kit text recognition is included to inspect screenshots and detect the Level 30 target label.
- This prototype is detection-only. It does **not** automatically tap Search, ATK, or March, and it has not been validated on a real device.

## Easiest build: GitHub Actions (no computer/Android Studio required)
1. Sign in to GitHub and create a **new repository**.
2. Upload the contents of this project folder to the repository (make sure `.github/workflows/build-apk.yml` is included).
3. Open the repository's **Actions** tab. If prompted, enable Actions.
4. Run **Build Android APK** (or wait for the first push build to finish).
5. Open the successful workflow run. Under **Artifacts**, download `LoJAutoHunter-debug-apk`.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then open it on your Android phone to install. Android may ask you to allow installation from that source.

The workflow builds a debug APK for testing. It is not a Play Store release.

## Build locally
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

Requires Android API 30+ because it uses AccessibilityService screenshot capture. Enable the service manually in Android Settings. Only use it while the game is open and stop it at any time.

## Next calibration needed
Test on the target phone: confirm that the game UI text is visible to OCR on (1) the search panel, (2) the fugitive result popup, (3) the troop deployment screen, and (4) the march/return state. Do not enable automatic March until these states are reliably distinguished.
