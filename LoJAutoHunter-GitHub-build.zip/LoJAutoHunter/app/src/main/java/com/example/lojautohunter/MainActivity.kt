package com.example.lojautohunter

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        layout.addView(TextView(this).apply {
            text = "LAND OF JAIL · AUTO HUNTER\n\nPrototype for Level 30 Frenzied Fugitive.\n\nAccessibility permission is required. The prototype is intentionally STOPPED by default."
            textSize = 19f
        })
        layout.addView(Button(this).apply {
            text = "Enable Accessibility Service"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "Open overlay permission"
            setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)) }
        })
        layout.addView(Button(this).apply {
            text = "Start / Stop (prototype)"
            setOnClickListener {
                HunterAccessibilityService.enabled = !HunterAccessibilityService.enabled
                text = if (HunterAccessibilityService.enabled) "Stop automation" else "Start / Stop (prototype)"
            }
        })
        setContentView(layout)
    }
}
