package com.example.lojautohunter

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/**
 * Safe prototype scaffold. It recognizes the target text but does not auto-attack yet.
 * The game is rendered as a map/canvas, so coordinates and post-search states need
 * device-specific calibration before enabling gesture automation.
 */
class HunterAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var busy = false

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (enabled) inspectScreen()
    }
    override fun onInterrupt() { enabled = false }

    private fun inspectScreen() {
        if (busy || !enabled) return
        busy = true
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                val hardware = screenshot.hardwareBuffer
                val bitmap = Bitmap.wrapHardwareBuffer(hardware, screenshot.colorSpace)
                hardware.close()
                if (bitmap == null) { busy = false; return }
                val image = InputImage.fromBitmap(bitmap, 0)
                recognizer.process(image)
                    .addOnSuccessListener { result ->
                        val text = result.text
                        // Detection only: never tap ATK/March automatically in this prototype.
                        if (text.contains("Lv.30 Frenzied Fugitive", ignoreCase = true) ||
                            text.contains("Target: Lv.30 Frenzied Fugitive", ignoreCase = true)) {
                            lastDetection = "Level 30 fugitive detected"
                        } else {
                            lastDetection = "Scanning game screen"
                        }
                    }
                    .addOnCompleteListener {
                        bitmap.recycle()
                        busy = false
                    }
            }
            override fun onFailure(errorCode: Int) { busy = false }
        })
    }

    companion object {
        @Volatile var enabled: Boolean = false
        @Volatile var lastDetection: String = "Waiting"
        @Volatile var instance: HunterAccessibilityService? = null
    }
}
